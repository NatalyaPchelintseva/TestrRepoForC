#include <stdio.h>
#define NMAX 10
int input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
int find_numbers(int *buffer, int length, int number, int *numbers);

/*------------------------------------
        Функция получает массив данных
        через stdin.
        Выдает в stdout особую сумму
        и сформированный массив
        специальных элементов
        (выбранных с помощью найденной суммы):
        это и будет частью ключа
-------------------------------------*/
int main() {
    int length, data[NMAX];
    if (!input(data, &length)) {
        printf("n/a");
    } else {
        int res_data[NMAX];
        int num = 0;
        int res = sum_numbers(data, length);
        printf("%d\n", res);
        int res_index = find_numbers(data, length, num, res_data);
        output(res_data, res_index);
    }
}
int input(int *a, int *n) {
    int counter = 0;
    int check = 0;
    if (!scanf("%d", n) && (*n > NMAX) && (*n <= 0)) {
        ++counter;
    }
    for (int *p = a; p - a < *n; p++) {
        if (!scanf("%d", p)) {
            ++counter;
        }
        if (*p % 2 == 0) {
            ++check;
        }
    }
    return (counter - check) >= 0 ? 0 : 1;
}

void output(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        printf("%d ", *(a++));
    }
    printf("%d", *a);
}

/*------------------------------------
        Функция должна находить
        сумму четных элементов
        с 0-й позиции.
-------------------------------------*/
int sum_numbers(int *buffer, int length) {
    int sum = 0;
    for (int *p = buffer; p - buffer < length; p++) {
        if ((*p != 0) && (*p % 2 == 0)) {
            sum += *p;
        }
    }
    return sum;
}

/*------------------------------------
        Функция должна находить
        все элементы, на которые нацело
        делится переданное число и
        записывает их в выходной массив.
-------------------------------------*/
int find_numbers(int *buffer, int length, int number, int *numbers) {
    int j = 0;
    number = sum_numbers(buffer, length);
    for (int *p = buffer; p - buffer < length; p++) {
        if ((*p != 0) && (number % *p == 0)) {
            *(numbers + j++) = *p;
        }
    }
    return j;
}
