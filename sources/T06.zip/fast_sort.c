#include <stdio.h>
#define NMAX 10

int read_array(int *arr, int size);
void quik_sort(int *arr, int size);
void heapify(int *arr, int size, int i);
void heap_sort(int *arr, int size);

int main() {
    int arr[NMAX];
    read_array(arr, NMAX);
    int arr1[NMAX];
    for (int i = 0; i < NMAX; i++) arr1[i] = arr[i];
    quik_sort(arr1, NMAX);
    int arr2[NMAX];
    for (int i = 0; i < NMAX; i++) arr2[i] = arr[i];
    heap_sort(arr2, NMAX);
    for (int i = 0; i < NMAX - 1; i++) printf("%d ", arr1[i]);
    printf("%d", arr1[NMAX - 1]);
    printf("\n");
    for (int i = 0; i < NMAX - 1; i++) printf("%d ", arr2[i]);
    printf("%d", arr2[NMAX - 1]);
    return 0;
}

int read_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("n/a");
            break;
        }
    }
    return 0;
}

void quik_sort(int *arr, int size) {
    if (size < 2) return;
    int pivot = arr[size / 2];
    int i, j;
    for (i = 0, j = size - 1;; i++, j--) {
        while (arr[i] < pivot) i++;
        while (arr[j] > pivot) j--;
        if (i >= j) break;
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    quik_sort(arr, i);
    quik_sort(arr + i, size - i);
}

void heapify(int *arr, int size, int i) {
    int largest = i;
    int leftChild = 2 * i + 1;
    int rightCild = 2 * i + 2;
    if (leftChild < size && arr[leftChild] > arr[largest]) largest = leftChild;
    if (rightCild < size && arr[rightCild] > arr[largest]) largest = rightCild;
    if (largest != i) {
        int temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;

        heapify(arr, size, largest);
    }
}

void heap_sort(int *arr, int size) {
    for (int i = size / 2 - 1; i >= 0; i--) heapify(arr, size, i);
    for (int i = size - 1; i >= 0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify(arr, i, 0);
    }
}
