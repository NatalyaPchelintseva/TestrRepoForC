#include <stdio.h>
#define LEN 100
void input(int *buffer, int *leng);
void output(int *buffer, int leng);
void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_leng);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_leng);
/*  Беззнаковая целочисленная длинная арифметика
    с использованием массивов.
    Ввод:
     * 2 длинных числа в виде массивов до 100 элементов
     * В один элемент массива нельзя вводить число > 9
    Вывод:
     * Результат сложения и разности чисел-массивов
    Пример:
     * 1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 6 1
       2 9

       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 9 0
       1 9 4 4 6 7 4 4 0 7 3 7 0 9 5 5 1 3 2
*/
int main() {
    int buffer1[LEN];
    int buffer2[LEN];
    int result[LEN + 1];
    int leng1 = LEN;
    int leng2 = LEN;
    int result_leng = LEN + 1;

    input(buffer1, &leng1);
    input(buffer2, &leng2);

    sum(buffer1, leng1, buffer2, leng2, result, &result_leng);
    output(result, result_leng);

    if (result_leng == LEN + 1) {
        sub(buffer1, leng1, buffer2, leng2, result, &result_leng);
        output(result, result_leng);
    }
    return 0;
}

void input(int *buffer, int *leng) {
    int digit;
    int i = 0;
    while (scanf("%d", &digit) == 1 && i < *leng) {
        buffer[*leng - 1 - i] = digit;
        i++;
    }
}

void output(int *buffer, int leng) {
    for (int i = leng - 1; i >= 0; i--) {
        printf("%d ", buffer[i]);
    }
    printf("/n");
}

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_leng) {
    int carry = 0;
    int max_len = len1 > len2 ? len1 : len2;

    for (int i = 0; i < max_len; i++) {
        int sum = carry;
        if (i < len1) {
            sum += buff1[i];
        }
        if (i < len2) {
            sum += buff2[i];
        }
        result[i] = sum % 10;
        carry = sum / 10;
    }

    if (carry > 0) {
        result[max_len] = carry;
        *result_leng = max_len + 1;
    } else {
        *result_leng = max_len + 1;
    }
}

void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_leng) {
    int borrow = 0;
    int max_len = len1 > len2 ? len1 : len2;

    for (int i = 0; i < max_len; i++) {
        int diff = borrow;
        if (i < len1) {
            diff += buff1[i];
        }
        if (i < len2) {
            diff -= buff2[i];
        }
        if (diff < 0) {
            printf("n/a");
            return;
        }
        result[i] = diff;
        borrow = 0;
    }
    while (result[max_len - 1] == 0 && max_len > 1) {
        max_len--;
    }

    *result_leng = max_len;
}
