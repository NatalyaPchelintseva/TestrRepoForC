#include <stdio.h>
#define NMAX 10

int input(int *data, int *n, int *c);
void output(int *data, int n);
void leftShift(int *data, int n, int c, int *result);
void rightShift(int *data, int n, int c, int *result);

int main() {
    int data[NMAX], result[NMAX], n, c;
    if (input(data, &n, &c)) {
        printf("n/a");
        return 1;
    }
    c = c - (c / n) * n;
    if (c > 0) {
        leftShift(data, n, c, result);
    } else if (c < 0) {
        rightShift(data, n, c, result);
    } else {
        output(data, n);
        return 0;
    }
    output(result, n);
}

int input(int *data, int *n, int *c) {
    double n_d, buf_d, c_d;
    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        return 1;
    };
    *n = (int)n_d;
    if (*n > 10 || *n <= 0) {
        return 1;
    }
    for (int i = 0; i < *n; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        data[i] = (int)buf_d;
    }
    if (scanf("%lf", &c_d) != 1 || (int)c_d != c_d) {
        return 1;
    }
    *c = (int)c_d;
    return 0;
}

void output(int *data, int n) {
    for (int i = 0; i < n - 1; ++i) {
        printf("%d ", data[i]);
    }
    printf("%d", data[n - 1]);
}

void leftShift(int *data, int n, int c, int *result) {
    int k = 0;
    for (int i = c; i < n; i++) {
        result[k] = data[i];
        k++;
    }
    for (int i = 0; i < c; i++) {
        result[k] = data[i];
        k++;
    }
}

void rightShift(int *data, int n, int c, int *result) {
    int k = 0;
    for (int i = n + c; i < n; i++) {
        result[k] = data[i];
        k++;
    }
    for (int i = 0; i < n + c; i++) {
        result[k] = data[i];
        k++;
    }
}
