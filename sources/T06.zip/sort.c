#include <stdio.h>
#define NMAX 10
int input(int *a);
void output(int *a, int n);
void sort(int *a, int n);
void swap(int *a, int *b);

int main() {
    int data[NMAX];
    if (!input(data)) {
        printf("n/a");
    } else {
        sort(data, NMAX);
        output(data, NMAX);
    }
}

int input(int *a) {
    int n = NMAX;
    int counter = 0;
    for (int *p = a; p - a < n; p++) {
        if (!scanf("%d", p)) {
            ++counter;
        }
    }
    return counter > 1 ? 0 : 1;
}

void sort(int *a, int n) {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; ++j) {
            if (a[j] > a[j + 1]) {
                swap(&a[j], &a[j + 1]);
            }
        }
    }
}

void output(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        printf("%d ", *(a++));
    }
    printf("%d", *a);
}

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}
