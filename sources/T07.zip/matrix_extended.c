#include <stdio.h>
#include <stdlib.h>

#define N 100
#define M 100

int choose_method();
int method1();
int method2();
int method3();
int method4();
void output_2d_arr(int **a, int m, int n);

int main() {
    int err = 0;
    switch (choose_method()) {
        case 1:
            err = method1();
            break;
        case 2:
            err = method2();
            break;
        case 3:
            err = method3();
            break;
        case 4:
            err = method4();
            break;
        default:
            err++;
    }
    return err;
}

int choose_method() {
    printf("Choose allocation method:\n");
    printf("1. Static array.\n");
    printf("2. Array of pointers to array segments within one buffer.\n");
    printf("3. Array of pointers to arrays.\n");
    printf("4. Array of pointers to segments of the second array.\n");
    int n;
    if (scanf("%d", &n) != 1) return 0;
    if (n < 1 || n > 4) return 0;
    return n;
}

void output_2d_arr(int **a, int m, int n) {
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++) printf("%d%s", a[i][j], (n - j) > 1 ? " " : "\n");
}

int method1() {
    int arr[M][N];
    int m, n;
    int err = 0;

    if (scanf("%d %d", &m, &n) != 2)
        err++;
    else if (m < 1 || n < 1 || m > M || n > N)
        err++;

    for (int i = 0; i < m && (!err); i++)
        for (int j = 0; j < n && (!err); j++)
            if (scanf("%d", &(arr[i][j])) != 1) err++;
    if (err)
        printf("n/a");
    else {
        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++) printf("%d%s", arr[i][j], (n - j) > 1 ? " " : "\n");
        int find;
        for (int i = 0; i < m; i++) {
            find = arr[i][0];
            for (int j = 1; j < n; j++)
                if (arr[i][j] > find) find = arr[i][j];
            printf("%d%s", find, (m - i) > 1 ? " " : "\n");
        }
        for (int i = 0; i < n; i++) {
            find = arr[0][i];
            for (int j = 1; j < m; j++)
                if (arr[j][i] < find) find = arr[j][i];
            printf("%d%s", find, (n - i) > 1 ? " " : "");
        }
    }
    return err;
}

int method2() {
    int m, n;
    int err = 0;

    if (scanf("%d %d", &m, &n) != 2)
        err++;
    else if (m < 1 || n < 1)
        err++;

    int **arr = malloc(m * n * sizeof(int) + m * sizeof(int *));
    int *p = (int *)(arr + m);
    for (int i = 0; i < m; i++) arr[i] = p + n * i;

    for (int i = 0; i < m && (!err); i++)
        for (int j = 0; j < n && (!err); j++)
            if (scanf("%d", &arr[i][j]) != 1) err++;

    if (err)
        printf("n/a");
    else {
        output_2d_arr(arr, m, n);
        int find;
        for (int i = 0; i < m; i++) {
            find = arr[i][0];
            for (int j = 1; j < n; j++)
                if (arr[i][j] > find) find = arr[i][j];
            printf("%d%s", find, (m - i) > 1 ? " " : "\n");
        }
        for (int i = 0; i < n; i++) {
            find = arr[0][i];
            for (int j = 1; j < m; j++)
                if (arr[j][i] < find) find = arr[j][i];
            printf("%d%s", find, (n - i) > 1 ? " " : "");
        }
    }
    free(arr);
    return err;
}

int method3() {
    int m, n;
    int err = 0;

    if (scanf("%d %d", &m, &n) != 2)
        err++;
    else if (m < 1 || n < 1)
        err++;

    int **arr = malloc(m * sizeof(int *));
    for (int i = 0; i < m; i++) arr[i] = malloc(n * sizeof(int));

    for (int i = 0; i < m && (!err); i++)
        for (int j = 0; j < n && (!err); j++)
            if (scanf("%d", &arr[i][j]) != 1) err++;

    if (err)
        printf("n/a");
    else {
        output_2d_arr(arr, m, n);
        int find;
        for (int i = 0; i < m; i++) {
            find = arr[i][0];
            for (int j = 1; j < n; j++)
                if (arr[i][j] > find) find = arr[i][j];
            printf("%d%s", find, (m - i) > 1 ? " " : "\n");
        }
        for (int i = 0; i < n; i++) {
            find = arr[0][i];
            for (int j = 1; j < m; j++)
                if (arr[j][i] < find) find = arr[j][i];
            printf("%d%s", find, (n - i) > 1 ? " " : "");
        }
    }
    for (int i = 0; i < m; i++) free(arr[i]);
    free(arr);
    return err;
}

int method4() {
    int m, n;
    int err = 0;

    if (scanf("%d %d", &m, &n) != 2)
        err++;
    else if (m < 1 || n < 1)
        err++;

    int **arr = malloc(m * sizeof(int *));
    int *values = malloc(m * n * sizeof(int));
    for (int i = 0; i < m; i++) arr[i] = values + n * i;

    for (int i = 0; i < m && (!err); i++)
        for (int j = 0; j < n && (!err); j++)
            if (scanf("%d", &arr[i][j]) != 1) err++;

    if (err)
        printf("n/a");
    else {
        output_2d_arr(arr, m, n);
        int find;
        for (int i = 0; i < m; i++) {
            find = arr[i][0];
            for (int j = 1; j < n; j++)
                if (arr[i][j] > find) find = arr[i][j];
            printf("%d%s", find, (m - i) > 1 ? " " : "\n");
        }
        for (int i = 0; i < n; i++) {
            find = arr[0][i];
            for (int j = 1; j < m; j++)
                if (arr[j][i] < find) find = arr[j][i];
            printf("%d%s", find, (n - i) > 1 ? " " : "");
        }
    }
    free(values);
    free(arr);
    return err;
}