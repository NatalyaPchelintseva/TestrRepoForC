#include <stdio.h>
#include <stdlib.h>

int input(int *matrix, int n, int m);
void output(int *matrix, int n, int m);
void sum(int *matrix_first, int *matrix_second, int *matrix_result, int n, int m);
void transpose(int *matrix, int n, int m);
void mul(int *matrix_first, int n_first, int m_first, int *matrix_second, int n_second, int m_second,
         int *matrix_result);
int choose_method();
int get_size(int *n1, int *m1);
int method1();
int method2();
int method3();

int main() {
    int err = 0;

    switch (choose_method()) {
        case 1:
            err = method1();
            break;
        case 2:
            err = method2();
            break;
        case 3:
            err = method3();
            break;
        default:
            err++;
    }
    return err;
}

int choose_method() {
    printf("Choose operation:\n");
    printf("1. Addition.\n");
    printf("2. Multiplication\n");
    printf("3. Transpose.\n");
    int n;
    if (scanf("%d", &n) != 1) return 0;
    if (n < 1 || n > 4) return 0;
    return n;
}

int get_size(int *n, int *m) {
    int err = 0;
    if (scanf("%d %d", n, m) != 2)
        err++;
    else if (*m < 1 || *n < 1)
        err++;
    return err;
}

int input(int *matrix, int n, int m) {
    for (int i = 0; i < (n * m); i++)
        if (scanf("%d", &(matrix[i])) != 1) return 1;
    return 0;
}

void output(int *matrix, int n, int m) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            printf("%d%s", matrix[i * m + j], (m - j) > 1 ? " " : ((n - i) > 1 ? "\n" : ""));
}

void sum(int *matrix_first, int *matrix_second, int *matrix_result, int n, int m) {
    for (int i = 0; i < (n * m); i++) matrix_result[i] = matrix_first[i] + matrix_second[i];
}

void mul(int *matrix_first, int n_first, int m_first, int *matrix_second, int n_second, int m_second,
         int *matrix_result) {
    for (int i = 0; i < n_first; i++) {
        for (int j = 0; j < m_second; j++) {
            matrix_result[i * n_first + j] = 0;
            for (int k = 0; k < n_second; k++) {
                matrix_result[i * n_first + j] +=
                    matrix_first[i * m_first + k] * matrix_second[k * m_second + j];
            }
        }
    }
}

void transpose(int *matrix, int n, int m) {
    int *res = malloc(n * m * sizeof(int));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) res[j * n + i] = matrix[i * m + j];
    for (int i = 0; i < (n * m); i++) matrix[i] = res[i];
    free(res);
}

int method1() {
    int err = 0;
    int n1, m1;
    int *matrix1 = NULL;
    if (get_size(&n1, &m1)) {
        err++;
        printf("n/a");
        return err;
    }
    matrix1 = malloc(n1 * m1 * sizeof(int));
    if (input(matrix1, n1, m1)) {
        free(matrix1);
        printf("n/a");
        return err;
    }

    int n2, m2;
    int *matrix2 = NULL;
    if (get_size(&n2, &m2))
        err++;
    else if (n1 != n2 || m1 != m2)
        err++;
    if (err) {
        free(matrix1);
        printf("n/a");
        return err;
    } else {
        matrix2 = malloc(n2 * m2 * sizeof(int));
        if (input(matrix2, n2, m2)) {
            free(matrix1);
            free(matrix2);
            printf("n/a");
            return err;
        }
    }

    int *matrix3 = malloc(n2 * m2 * sizeof(int));

    sum(matrix1, matrix2, matrix3, n2, m2);

    output(matrix3, n1, m1);
    free(matrix1);
    free(matrix2);
    free(matrix3);
    return err;
}

int method2() {
    int err = 0;
    int n1, m1;
    int *matrix1 = NULL;
    if (get_size(&n1, &m1)) {
        err++;
        printf("n/a");
        return err;
    }
    matrix1 = malloc(n1 * m1 * sizeof(int));
    if (input(matrix1, n1, m1)) {
        free(matrix1);
        printf("n/a");
        return err;
    }

    int n2, m2;
    int *matrix2 = NULL;
    if (get_size(&n2, &m2))
        err++;
    else if (m1 != n2)
        err++;
    if (err) {
        free(matrix1);
        printf("n/a");
        return err;
    } else {
        matrix2 = malloc(n2 * m2 * sizeof(int));
        if (input(matrix2, n2, m2)) {
            free(matrix1);
            free(matrix2);
            printf("n/a");
            return err;
        }
    }

    int *matrix3 = malloc(n1 * m2 * sizeof(int));

    mul(matrix1, n1, m1, matrix2, n2, m2, matrix3);

    output(matrix3, n1, m2);
    free(matrix1);
    free(matrix2);
    free(matrix3);
    return err;
}

int method3() {
    int err = 0;
    int n1, m1;
    int *matrix1 = NULL;
    if (get_size(&n1, &m1)) {
        err++;
        printf("n/a");
        return err;
    }
    matrix1 = malloc(n1 * m1 * sizeof(int));
    if (input(matrix1, n1, m1)) {
        free(matrix1);
        printf("n/a");
        return err;
    }

    transpose(matrix1, n1, m1);
    output(matrix1, m1, n1);
    free(matrix1);
    return err;
}