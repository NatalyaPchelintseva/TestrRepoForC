#include <stdio.h>

int max(int a, int b);
int main() {
  int a, b;

  if ((scanf("%d %d", &a, &b)) == 2)
    printf("%d\n", max(a, b));

  else
    printf(" n/a\n");
}

int max(int a, int b) {
  int m = a;
  if (b > a)
    m = b;

  return m;
}
