#include <math.h>
#include <stdio.h>

int main() {

  double a, b;

  if ((scanf("%lf", &a)) == 1) {
      b = 7 * pow(10, -3) * pow(a, 4) + ((22.8 * pow(a, 1/3) - pow(10, 3)) * a + 3) / (a * a / 2) - a * pow((10 + a), (2/a)) - 1.01;

    printf("%.1f\n", b);
  }
  else
    printf("n/a\n");
  return 0;
}
