#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

int main() {
    stack my_stack;
    stack* test = &my_stack;
    init(test);
    push(test, 3);
    push(test, 4);
    push(test, 5);
    push(test, 6);
    stack_print(test);

    printf("push test\n");
    int T1 = pop(test);
    printf("Exp 6 / Res %d\n", T1);
    if (T1 == 6)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    push(test, 6);
    push(test, 7);
    stack_print(test);
    int T2 = pop(test);
    printf("Exp 7 / Res %d\n", T2);
    if (T2 == 7)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    push(test, 7);

    printf("\npop test\n");
    stack_print(test);
    int T3 = pop(test);
    printf("Exp 7 / Res %d\n", T3);
    if (T3 == 7)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    stack_print(test);
    int T4 = pop(test);
    printf("Exp 6 / Res %d\n", T4);
    if (T4 == 6)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");

    stack_print(test);

    destroy(test);
    return 0;
}

void stack_print(stack* st) {
    printf("Stack: ");
    for (int j = 0; j != st->i; j++) {
        printf("%d ", st->data[j]);
    }
    printf("\n");
}
