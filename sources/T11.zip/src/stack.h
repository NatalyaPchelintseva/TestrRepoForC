#ifndef STACK_H_
#define STACK_H_

typedef struct stack {
    int* data;
    int capacity;
    int i;
} stack;

void init(stack* st);
void push(stack* st, int d);
int pop(stack* st);
stack* destroy(stack* st);

void stack_print(stack* st);

#endif
