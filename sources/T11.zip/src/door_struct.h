#ifndef DOOR_STRUCT_H_
#define DOOR_STRUCT_H_
typedef struct door {
    int id;
    int status;
} door;
#endif
