#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

void init(stack* st) {
    st->capacity = 10;
    st->data = malloc(st->capacity * sizeof(int));
    st->i = 0;
}

void push(stack* st, int d) {
    if (st->i == st->capacity - 1) {
        st->capacity *= 2;
        st->data = realloc(st->data, st->capacity * sizeof(int));
    }
    st->data[st->i] = d;
    st->i++;
}

int pop(stack* st) {
    int temp = st->data[st->i - 1];
    st->i--;
    return temp;
}

stack* destroy(stack* st) {
    while (st->i != 0) pop(st);
    free(st->data);
    return st;
}
