#include <ncurses.h>
#include <stdio.h>

#define WIDTH 80
#define HEIGHT 25
#define START_SPEED 200
#define START_GEN 0
#define FALSE_SET " "
#define TRUE_SET "*"

void init_game();
void game(int matrix[HEIGHT][WIDTH]);
int input(int matrix[HEIGHT][WIDTH]);
int same_array(int matrix_first[HEIGHT][WIDTH], int matrix_second[HEIGHT][WIDTH]);
int null_array(int matrix[HEIGHT][WIDTH]);
int sum_environment(int matrix[HEIGHT][WIDTH], int y, int x);
int cell_status(int matrix[HEIGHT][WIDTH], int y, int x);
int next_step(int matrix[HEIGHT][WIDTH]);
void output(int matrix[HEIGHT][WIDTH]);
int speed_change(int speed, char key);

int main() {
    int matrix[HEIGHT][WIDTH] = {0};
    printf("Введине начальное состояние для массива %d Х %d:\n", HEIGHT, WIDTH);
    int vvod = input(matrix);
    FILE *tty = freopen("/dev/tty", "r", stdin);
    if (vvod && tty) {
        game(matrix);
    } else {
        printf("Не верно введены данные!\n");
    }
    return 0;
}

void init_game() {
    char c;
    do {
        c = getchar();
        erase();
    } while (c != 's');
}

void game(int matrix[HEIGHT][WIDTH]) {
    size_t generation = START_GEN;
    int speed = START_SPEED;
    char key;
    int final = 1;
    initscr();
    printw("Press key \"s\" for start game!\n");
    printw("Generation: %zu\n", generation);
    output(matrix);
    refresh();
    init_game();
    noecho();
    curs_set(0);
    do {
        erase();
        printw("Game of Life! (press key \"q\" to finish | \"+\" faster | \"-\" slower)\n");
        printw("Generation: %zu\n", generation++);
        output(matrix);
        nodelay(stdscr, TRUE);
        key = getch();
        char str[1];
        getstr(str);
        speed = speed_change(speed, key);
        refresh();
        napms(speed);
        final = next_step(matrix);
    } while (key != 'q' && final == 1);
    if (final == 1) {
        printw("Game is finished by player!\n");
    } else {
        printw("Game is finished!\n");
    }
    printw("Input any key...\n");
    refresh();
    getchar();
    endwin();
}

int speed_change(int speed, char key) {
    if (key == '-') {
        speed += 10;
    }
    if (key == '+') {
        if (speed <= 11) {
            speed = 10;
        } else {
            speed -= 10;
        }
    }
    return speed;
}

int input(int matrix[HEIGHT][WIDTH]) {
    int res = 1;
    int x;
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (scanf("%1d", &x) == 1 && (x == 1 || x == 0)) {
                matrix[i][j] = x;
            } else {
                res = 0;
            }
        }
    }
    char c;
    scanf("%c", &c);
    if (c != '\n' && c != '\0') {
        res = 0;
    }
    return res;
}

void output(int matrix[HEIGHT][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (matrix[i][j] == 0) {
                printw(FALSE_SET);
            }
            if (matrix[i][j] == 1) {
                printw(TRUE_SET);
            }
        }
        printw("\n");
    }
}

int next_step(int matrix[HEIGHT][WIDTH]) {
    int res = 1;
    int matrix_second[HEIGHT][WIDTH] = {0};
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            matrix_second[i][j] = cell_status(matrix, i, j);
        }
    }
    if (!null_array(matrix) || !same_array(matrix, matrix_second)) {
        res = 0;
    } else {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                matrix[i][j] = matrix_second[i][j];
            }
        }
    }
    return res;
}

int cell_status(int matrix[HEIGHT][WIDTH], int y, int x) {
    int status = 0;
    int sum = sum_environment(matrix, y, x);
    if (sum == 3) {
        status = 1;
    }
    if (sum == 2) {
        status = matrix[y][x];
    }
    return status;
}

int sum_environment(int matrix[HEIGHT][WIDTH], int y, int x) {
    int sum = -matrix[y][x];
    for (int i = y - 1; i < y + 2; i++) {
        for (int j = x - 1; j < x + 2; j++) {
            sum = sum + matrix[(i + HEIGHT) % HEIGHT][(j + WIDTH) % WIDTH];
        }
    }
    return sum;
}

int null_array(int matrix[HEIGHT][WIDTH]) {
    int res = 0;
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (matrix[i][j] != 0) {
                res = 1;
            }
        }
    }
    return res;
}

int same_array(int matrix_first[HEIGHT][WIDTH], int matrix_second[HEIGHT][WIDTH]) {
    int res = 0;
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (matrix_first[i][j] != matrix_second[i][j]) {
                res = 1;
            }
        }
    }
    return res;
}
