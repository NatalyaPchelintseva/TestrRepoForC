#ifndef SRC_S21_STRING_H_
#define SRC_S21_STRING_H_

int s21_strlen(const char* str);
void s21_strlen_test();
int s21_strcmp(const char* str1, const char* str2);
void s21_strcmp_test();
void s21_strcpy();
void s21_strcpy(char* destination, const char* source);
void s21_strcat();
void s21_strcat(char* destination, const char* source);

#endif  // SRC_S21_STRING_H_