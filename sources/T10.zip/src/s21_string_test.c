#include "s21_string.h"

#include <stdio.h>

void s21_strlen_test() {
    printf("TESTING STRLEN MODULE\n");
    s21_strlen("Marusia 160618") == 14 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strlen("\0") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strlen("") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
}

void s21_strcmp_test() {
    printf("TESTING STRCMP MODULE\n");
    s21_strcmp("Marusia", "Marusia18") < 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcmp("", "Marusia") < 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcmp("Marusia18", "Marusia18") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
}

void s21_strcpy_test() {
    printf("TESTING STRCPY MODULE\n");
    char str1[] = "MARUSIA160618";
    char str2[] = "160618";
    char str3[] = "DOT";
    s21_strcpy(str1, str2);
    s21_strcmp(str1, str2) == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcpy(str2, str1);
    s21_strcmp(str2, str1) == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcpy(str1, str3);
    s21_strcmp(str1, str3) == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
}

void s21_strcat_test() {
    printf("TESTING STRCAT MODULE\n");
    char str[80];
    char str1[] = "MARUSIA";
    char str2[] = "1606";
    char str3[] = "DOT";
    s21_strcpy(str, str1);
    s21_strcat(str, str2);
    s21_strcmp(str, "MARUSIA") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcat(str, str3);
    s21_strcmp(str, "MARUSIA1606") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
    s21_strcat(str, str2);
    s21_strcmp(str, "MARUSIA1606DOT") == 0 ? printf("SUCCESS\n") : printf("FAIL\n");
}