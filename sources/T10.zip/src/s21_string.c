#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

int s21_strlen(const char* str) {
    int len = 0;
    while (str[len] != '\0') {
        len++;
    }
    return len;
}

int s21_strcmp(const char* str1, const char* str2) {
    int i = 0, status = 0;
    while (str1[i] != '\0' && str2[i] != '\0' && status == 0) {
        if ((int)str1[i] < (int)str2[i]) {
            status = -1;
        }
        if ((int)str1[i] > (int)str2[i]) {
            status = 1;
        }
        i++;
    }
    if (str1[i] == '\0' && str2[i] == '\0') {
        status = 0;
    } else if (str1[i] == '\0' && str2[i] != '\0') {
        status = -1;
    } else if (str1[i] != '\0' && str2[i] == '\0') {
        status = 1;
    }
    return status;
}

void s21_strcpy(char* destination, const char* source) {
    int i = 0;
    while (source[i] != '\0') {
        destination[i] = source[i];
        i++;
    }
    destination[i] = '\0';
}

void s21_strcat(char* destination, const char* source) {
    int len, i = 0;
    len = s21_strlen(destination);
    while (source[i] != '\0') {
        destination[len + i] = source[i];
        i++;
    }
    destination[len + i] = '\0';
}