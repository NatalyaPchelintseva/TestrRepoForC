#include <stdio.h>

#include "s21_string.h"

int main() {
#ifdef Quest_1
    s21_strlen_test();
#endif
#ifdef Quest_2
    s21_strcmp_test();
#endif
#ifdef Quest_3
    s21_strcmp_test();
#endif
#ifdef Quest_4
    s21_strcmp_test();
#endif

    return 0;
}
