#include<stdlib.h>

#define sin 'S'
#define cos 'C'
#define tan 'T'
#define ctg 'CT'
#define sqrt 'KOR'
#define ln 'LN'

struct Stek{
    char c;
    struct Stek* Next;
};

double parcer(char string[100], double x){
    
    struct Stek* t, *topElem = NULL;
    char curSymbol, buffer[100];
    int stringIndex = 0, bufferIndex = 0;
    
    while (string[stringIndex] != '\0') {
        if(string[stringIndex] == ")"){
            
            while((topElem -> c)!="("){
                topElem = clearStek(topElem, &curSymbol);
                
                if(!topElem){
                    curSymbol="/0";
                }
                buffer[bufferIndex++] = curSymbol;
                buffer[bufferIndex++] = ' ';
            }
            
            t = topElem;
            topElem = topElem -> Next;
            free(t);
        }
        if ((string[stringIndex] == 's' && string[stringIndex+1] == 'i'
       && string[stringIndex+2] == 'n' && string[stringIndex+3] == '(')) {
      topElem = loadStek(topElem, sin);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 's' && string[stringIndex+1] == 'i'
       && string[stringIndex+2] == 'n' && string[stringIndex+3] == '(')) {
      topElem = loadStek(topElem, sin);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 'c' && string[stringIndex+1] == 'o'
       && string[stringIndex+2] == 's' && string[stringIndex+3] == '(')) {
      topElem = loadStek(topElem, cos);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 't' && string[stringIndex+1] == 'a'
       && string[stringIndex+2] == 'n' && string[stringIndex+3] == '(')) {
      topElem = loadStek(topElem, tan);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 'c' && string[stringIndex+1] == 't'
      && string[stringIndex+2] == 'g' && string[stringIndex+3] == '(')) {
      topElem = loadStek(topElem, ctg);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 's' && string[stringIndex+1] == 'q'
      && string[stringIndex+2] == 'r' && string[stringIndex+3] == 't' && string[stringIndex+4] == '(')) {
      topElem = loadStek(topElem, sqrt);
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] == 'l' && string[stringIndex+1] == 'n' && string[stringIndex+2] == '(')) {
      topElem = loadStek(topElem, ln);
      buffer[bufferIndex++] = ' ';
    }
    if (string[stringIndex] == 'x') {
      buffer[bufferIndex++] = string[stringIndex];
      buffer[bufferIndex++] = ' ';
    }
    if ((string[stringIndex] >= '0' && string[stringIndex] <= '9')
      && (string[stringIndex+1] >= '0' && string[stringIndex+1] <= '9')) {
      buffer[bufferIndex++] = string[stringIndex];
    } else if (string[stringIndex] >= '0' && string[stringIndex] <= '9') {
      buffer[bufferIndex++] = string[stringIndex];
      buffer[bufferIndex++] = ' ';
    }

    if ( string[stringIndex] == '(' )
      topElem = loadStek(topElem, string[stringIndex]);
    if ( string[stringIndex] == '+' || string[stringIndex] == '-' || string[stringIndex] == '*'
      || string[stringIndex] == '/' || string[stringIndex] == 'S' || string[stringIndex] == 'C'
      || string[stringIndex] == 'T' || string[stringIndex] == 'CT' || string[stringIndex] == 'LN'
      || string[stringIndex] == 'KOR') {
      while (topElem != NULL && Prioritet(topElem -> c) >= Prioritet(string[stringIndex])) {
        topElem = clearStek(topElem, &curSymbol);
        buffer[bufferIndex++] = curSymbol;
        buffer[bufferIndex++] = ' ';
      }
    topElem = loadStek(topElem, string[stringIndex]);
    }
    stringIndex++;
  }
  while (topElem !=NULL) {
    topElem = clearStek(topElem, &curSymbol);
    buffer[bufferIndex++] = curSymbol;
  }
  buffer[bufferIndex] = '\0';
  return parserf(buffer, x);
}
int Prioritet(char a) {
  switch (a) {
    case 'KOR': return 5;
    case 'S': case 'C': case 'T': case 'CT': case 'LN': return 4;
    case '*': case '/': return 3;
    case '-': case '+': return 2;
    case '(': return 1;
  }
  return 0;
}
struct Stek* loadStek(struct Stek *t, char s) {
  struct Stek *t1 = (struct Stek*)malloc(sizeof(struct Stek));
  t1 -> c = s;
  t1-> Next = t;
  return t1;
}
struct Stek* clearStek(struct Stek *t, char *s) {
  struct Stek *t1 = t;
  *s = t -> c;
  t = t-> Next;
  free(t1);
  return t;
}
