#ifndef PARSER
#define PARSER

double parserf(char string[100], double x);
int Prioritet(char);
struct Stek* loadStek(struct Stek*, char);
struct Stek* clearStek(struct Stek*, char*);
#endif
