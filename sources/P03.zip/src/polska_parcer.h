#ifndef LOCAL_REPOS_P03D20_0_SRC_POLSKA_PARCER_H_
#define LOCAL_REPOS_P03D20_0_SRC_POLSKA_PARCER_H_

double polska_parcer(char formula[100], double x);

#endif  // LOCAL_REPOS_P03D20_0_SRC_POLSKA_PARCER_H_
