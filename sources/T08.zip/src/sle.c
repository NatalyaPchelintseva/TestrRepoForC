int sle(double **matrix, int n, int m, double *roots);
void input(double **matrix, int *n, int *m);
void output(double **matrix, int n, int m);
void output_roots(double *roots, int n);

void main() {}
