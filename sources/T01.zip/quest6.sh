bash ai_help/keygen.sh
cd ai_help/key
find .  -type f ! -name "*.*" -delete
cd ..
bash unifier.sh
