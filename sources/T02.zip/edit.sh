#!/bin/bash
filename=$1
search=$2
replace=$3



if [[ $2 != "" && $3 != "" ]]; 
then
sed -i "" "s/$2/$3/" $1;
          size=$(stat -f %z $filename)
          date=$(stat -f %Sm -t "%Y-%m-%d %H:%M" $filename)
          shasum=$(shasum -a 256 $filename | cut -d " " -f 1)
echo "src/$1 - $size - $date - $shasum - sha256" >> files.log
else
echo "недостаточно данных"
fi
