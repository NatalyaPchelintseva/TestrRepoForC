#!/bin/bash

#Передача аргумента с путем
if
[ -z "$1" ];
then
echo "Usage: $0 <path_to_log_file>"
exit 1
fi

log_file=$1

#проверка существования файла
if [ ! -f "$log_file" ]
then
echo "File not found: $log_file"
exit 1
fi

   total_entries=$(wc -l < "$log_file")
   unique_file=$(awk -F ' - ' '{print $1}' "$log_file" | sort | uniq | wc -l)
   changed_hashes=$(awk -F ' - ' '{print $4}' "$log_file" | grep -v NULL | uniq | wc -l)
   echo total_entries:$total_entries unique_files:$unique_file changed_hashes:$changed_hashes


