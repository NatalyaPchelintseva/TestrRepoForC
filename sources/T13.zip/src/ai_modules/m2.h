#ifndef M2_H
#define M2_H

void m2_f1();

#endif

