#include "data_stat.h"

double max(double *data, int n) {
    int max = data[0];
    for (int i = 0; i < n; i++) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    return max;
}

double min(double *data, int n) {
    int min = data[0];
    for (int i = 0; i < n; i++) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    return min;
}

double mean(double *data, int n) {
    double oz = 0;
    for (int i = 0; i < n; i++) {
        oz += data[i];
    }
    return oz / n;
}

double variance(double *data, int n) {
    double mean_var = mean(data, n);
    double var = 0;
    for (int i = 0; i < n; i++) {
        var += (data[i] - mean_var) * (data[i] - mean_var);
    }
    var = var / n;
    return var;
}
