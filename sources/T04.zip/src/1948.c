#include <stdio.h>

int find_max_prime_divisor(int a) {
  int max_divisor = 0;
  for (int i = 2 <= (a / 2) i++) {
    if (a % i == 0) {
      max_divisor = i;
    }
  }
  return max_divisor;
}

int main() {
  int a;
  printf("Введите целое число: ");
  scanf("%d", &a);
  int max_prime_divisor = find_max_prime_divisor(a);
  if (max_prime_divisor == 0) {
    printf("n/a");
  } else {
    printf("Наибольший простой делитель числа %d равен %d\n", a,
           max_prime_divisor);
  }
  return 0;
}
