#include <stdio.h>

long long fibonacci(long long n);

int main() {
  long long n;
  printf("Введите число: ");

  if (scanf("%lld", &n) != 1 || n < 0)
    printf("n/a\n");
  else
    printf("%lld\n", fibonacci(n));
  return 0;
}

long long fibonacci(long long n) {
  if (n <= 1)
    return n;
  else
    return fibonacci(n - 1) + fibonacci(n - 2);
}
